<?php

$servername = "localhost";
$username = "USERmainevent";
$password = "1234-USER";
$databasename = "DBmainevent";
    

$conn = new mysqli($servername,$username,$password,$databasename);

if($conn->connect_error){
	die ("Connection failed : ".$conn->connect_error);
}
// echo "Connected successfully";

?>