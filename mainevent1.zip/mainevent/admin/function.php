<?php 
session_start();
include 'config.php';

// Add Data
if($_GET['act'] == 'addEvent'){
	$company 	 = $_POST['company'];
	$category 	 = $_POST['category'];
	$subject 	 = $_POST['subject'];
	$description = $_POST['description'];
	$date 		 = $_POST['date'];
	$location 	 = $_POST['location'];
	$payment 	 = $_POST['payment'];
	$img 	 	 = $_POST['img'];

	$querytambah =  mysqli_query($conn, "INSERT INTO event (`company`, `category`, `subject`, `description`, `date`, `location`, `payment`, `img`) VALUES ('$company', '$category', '$subject', '$description', '$date', '$location', '$payment', '$img')");

	if ($querytambah) {
		echo "<meta http-equiv='refresh' content='0; ../admin.php?act=Add-Success&$company-$category'>";
	}
	else{
		echo "<meta http-equiv='refresh' content='0; ../admin.php?act=Add-Failed&$company-$category'>". mysqli_error($conn);
	}
}

// Edit Event
elseif($_GET['act'] == 'editEvent'){
	$id 	 	 = $_POST['id'];
	$company 	 = $_POST['company'];
	$category 	 = $_POST['category'];
	$subject 	 = $_POST['subject'];
	$description = $_POST['description'];
	$location 	 = $_POST['location'];
	$date 		 = $_POST['date'];
	$payment 	 = $_POST['payment'];
	$img 	 	 = $_POST['img'];

	$queryupdate = mysqli_query($conn, "UPDATE event SET company='$company', category='$category', subject='$subject', description='$description', location='$location', date='$date', payment='$payment', img='$img' WHERE id='$id' ");

	if ($queryupdate) {
		echo "<meta http-equiv='refresh' content='0; ../admin.php?act=Edit-Success&id=$id'>";
	}
	else{
		echo "<meta http-equiv='refresh' content='0; ../admin.php?act=Edit-Failed&id=$id'>".mysqli_error($conn);
	}
}

// Delete Event
elseif ($_GET['act'] == 'deleteEvent'){
	$id = $_GET['id'];

	$queryinsert = mysqli_query($conn, "INSERT INTO history SELECT * FROM event WHERE id = '$id'");
	$querydelete = mysqli_query($conn, "DELETE FROM event WHERE id = '$id'");

	if ($querydelete) {
		echo "<meta http-equiv='refresh' content='0; ../admin.php?act=Delete-Success&id=$id'>";
	}
	else{
		echo "<meta http-equiv='refresh' content='0; ../admin.php?act=Delete-Failed&id=$id'>".mysqli_error($conn);
	}
}

// Destroy Event
elseif ($_GET['act'] == 'destroyEvent'){
	$id = $_GET['id'];

	$querydelete = mysqli_query($conn, "DELETE FROM history WHERE id = '$id'");

	if ($querydelete) {
		echo "<meta http-equiv='refresh' content='0; ../historyevent.php?act=Destroy-Success&id=$id'>"; 
	}
	else{
		echo "<meta http-equiv='refresh' content='0; ../historyevent.php?act=Destroy-Failed&id=$id'>".mysqli_error($conn); 
	}
}

// Delete Event
elseif ($_GET['act'] == 'undoEvent'){
	$id = $_GET['id'];

	$queryinsert = mysqli_query($conn, "INSERT INTO event SELECT * FROM history WHERE id = '$id'");
	$querydelete = mysqli_query($conn, "DELETE FROM history WHERE id = '$id'");

	if ($querydelete) {
		echo "<meta http-equiv='refresh' content='0; ../historyevent.php?act=Delete-Success&id=$id'>"; 
	}
	else{
		echo "<meta http-equiv='refresh' content='0; ../historyevent.php?act=Delete-Failed&id=$id'>".mysqli_error($conn); 
	}
}

// Add Register Event User
elseif($_GET['act'] == 'regEvent'){
	$name 	 = $_POST['name'];
	$email 	 = $_POST['email'];
	$phone 	 = $_POST['phone'];

	$sql =  mysqli_query($conn, "INSERT INTO register (`name`, `email`, `phone`) VALUES ('$name', '$email', '$phone')");

	if ($sql) {
		echo "<script>alert('Registered Berhasil, Kami akan segera menghubungi Anda. Terima Kasih.')</script>";
		echo "<meta http-equiv='refresh' content='0; ../index.php?act=Registered-Success&name=$name'>";
	}
	else{
		echo "<script>alert('Registered Gagal, Silakan coba kembali. Terima Kasih.')</script>";
		echo "<meta http-equiv='refresh' content='0; ../index.php?act=Registered-Failed&name=$name'>".mysqli_error($conn);
	}
}

// Edit Register Event User
elseif($_GET['act'] == 'editRegister'){
	$id 	 	 = $_POST['id'];
	$name 	 	 = $_POST['name'];
	$email 	 	 = $_POST['email'];
	$phone 	 	 = $_POST['phone'];
	$respons 	 = $_POST['respons'];
	
	$sql = mysqli_query($conn, "UPDATE register SET name='$name', email='$email', phone='$phone', respons='$respons' WHERE id='$id' ");

	if ($sql) {
		echo "<meta http-equiv='refresh' content='0; ../registerevent.php?$act=Edit-Success&id=$id'>";    
	}
	else{
		echo "<meta http-equiv='refresh' content='0; ../registerevent.php?act=Edit-Failed&id=$id'>".mysqli_error($conn);
	}
}

// Delete Event
elseif ($_GET['act'] == 'deleteRegister'){
	$id = $_GET['id'];

	$querydelete = mysqli_query($conn, "DELETE FROM register WHERE id = '$id'");

	if ($querydelete) {
		echo "<meta http-equiv='refresh' content='0; ../registerevent.php?act=Delete-Success&id=$id'>";   
	}
	else{
		echo "<meta http-equiv='refresh' content='0; ../registerevent.php?act=Delete-Failed&id=$id'>".mysqli_error($conn);   
	}
}

?>