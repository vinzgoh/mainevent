<?php
session_start();

include "config.php";

$email	  = $_POST['email'];
$password = $_POST['password'];
$password = md5($password);

$sql 	  = mysqli_query($conn, "SELECT * FROM user WHERE email = '$email' AND password = '$password'");
$data	  = mysqli_fetch_array($sql);

if (!empty($data)){
	$_SESSION['email'] = $data['email'];
	$_SESSION['email'] = $data['email'];
	setcookie("message","delete",time()-1);
	
	header('location:../admin.php');
}else{
	setcookie("message", "Maaf, email atau Password salah", time()+3600);

	header("location: ../admin/login.php");
}
?>