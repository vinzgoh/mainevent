<?php 
include 'admin/config.php';
?>

<!DOCTYPE html>
<html lang="zxx" class="no-js">
<head>
	<!-- Mobile Specific Meta -->
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<!-- Favicon-->
	<link rel="shortcut icon" href="img/logo5.png">
	<!-- Author Meta -->
	<meta name="author" content="">
	<!-- Meta Description -->
	<meta name="description" content="">
	<!-- Meta Keyword -->
	<meta name="keywords" content="">
	<!-- meta character set -->
	<meta charset="UTF-8">
	<!-- Site Title -->
	<title>MAINevent</title>

	<link href="https://fonts.googleapis.com/css?family=Poppins:100,200,400,300,500,600,700" rel="stylesheet">
			<!--
			CSS
			============================================= -->
			<link rel="stylesheet" href="css/linearicons.css">
			<link rel="stylesheet" href="css/font-awesome.min.css">
			<link href="css/availability-calendar.css" rel="stylesheet">
			<link rel="stylesheet" href="css/magnific-popup.css">
			<link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
			<link rel="stylesheet" href="css/bootstrap.css">
			<link rel="stylesheet" href="css/main.css">

			<!-- Scrool Reveal -->
			<script src="https://unpkg.com/scrollreveal"></script>

			<!-- Global site tag (gtag.js) - Google Analytics -->
			<script async src="https://www.googletagmanager.com/gtag/js?id=UA-147978872-1"></script>
			<script>
				window.dataLayer = window.dataLayer || [];
				function gtag(){dataLayer.push(arguments);}
				gtag('js', new Date());

				gtag('config', 'UA-147978872-1');
			</script>
		</head>
		<body>

			<!-- Start Header Area -->
			<header class="default-header">
				<div class="container">
					<div class="header-wrap">
						<div class="header-top d-flex justify-content-between align-items-center">
							<div class="logo">
								<a href="#home"><img src="img/logo4.png" alt="" style="width: 300px"></a>
							</div>
							<div class="main-menubar d-flex align-items-center">
								<nav class="hide">
									<a href="#home">Home</a>
									<a href="#speaker">Popular Event</a>
									<a href="#Calendar1">Event Calendar</a>
									<a href="#upcoming">Upcoming event</a>
								</nav>
								<div class="menu-bar"><span class="lnr lnr-menu"></span></div>
							</div>
						</div>
					</div>
				</div>
			</header>
			<!-- End Header Area -->


			<!-- start banner Area -->
			<section class="relative" id="home" style="background-image: url(img/header-bg.jpg); background-size: cover;">
				<div class="overlay"></div>
				<div class="container">
					<div class="row fullscreen align-items-center justify-content-start">
						<div class="banner-content col-lg-6 col-md-6" style="top: 40px">
							<h1><b>In Coming Event</b></h1>
							<div class=" clock_sec d-flex flex-row justify-content-between" id="clockdiv" style="border-radius: 10px;" >
								<div class="clockinner">
									<span class="days"></span>
									<div class="smalltext">Days</div>
								</div>
								<div class="clockinner">
									<span class="hours"></span>
									<div class="smalltext">Hours</div>
								</div>
								<div class="clockinner">
									<span class="minutes"></span>
									<div class="smalltext">Minutes</div>
								</div>
								<div class="clockinner">
									<span class="seconds"></span>
									<div class="smalltext">Seconds</div>
								</div>
							</div>
							<div class="mt-10">
								<a href="#upcoming" class="nw-btn primary-btn">See More<span class="lnr lnr-chevron-down"></span></a>
							</div>
							<div class="row">
								<div class="col-lg-12 mx-auto">
									<div class="mt-3">
										<form action="#upcoming">
											<div class="p-1 bg-light mb-1" style="border-radius: 25px;">
												<div class="input-group">
													<input type="search" placeholder="What're you searching for?" aria-describedby="button-addon1" class="form-control border-0 bg-light" style="border-radius: 25px;">
													<div class="input-group-append">
														<button type="submit" class="nw-btn primary-btn">Search<span class="fa fa-search"></span></button>
													</div>
												</div>
											</div>
										</form>
										<!-- End -->
									</div>
								</div>
							</div>
						</div>
						<div class="col-lg-2 col"></div>
						<div class="banner-content col-lg-4 col-md-6 mt-5">
							<form action="admin/function.php?act=regEvent" enctype="multipart/form-data" method="POST" class="request-form p-3" style="background-color: #f9f9ff; border-radius: 10px;">
								<div class="single-footer-widget m-10 ">
									<h2 class="pb-20">Register Your Event</h2>
									<div class="form-group">
										<input type="text" class="form-control" name="name" placeholder="Enter your Name" required>
									</div>
									<div class="form-group">
										<input type="email" class="form-control" name="email" placeholder="Enter your Email" required>
									</div>
									<div class="form-group">
										<input type="number" class="form-control" name="phone" placeholder="Enter your Phone" required>
									</div>
									<div class="form-group">
										<button type="submit" class="nw-btn primary-btn">Register<span class="lnr lnr-arrow-right"></span></button>
									</div>
								</div>
							</form>
						</div>
					</div>
				</div>
			</section>
			<!-- End banner Area -->


			<!-- Start Popular Area -->
			<section class="speaker-area section-gap" id="speaker">
				<div class="container">
					<div class="row d-flex justify-content-center">
						<div class="col-md-8 pb-80 header-text">
							<h1>Popular Event</h1>
							<p>
								Ayo daftarkan segera acara-acara terhits dan menarik kamu untuk dapat kami tampilkan pada website kami.
							</p>
						</div>
					</div>
					<div class="row">
						<div class="col-12 col-md-4 col-lg-5">
							<div class="single-speaker">
								<div class="content">
									<img class="content-image img-fluid d-block mx-auto" src="img/logo6.png" alt="">
									<div class="content-details fadeIn-bottom"></div>
								</div>
							</div>
						</div>
						<div class="col-12 col-md-8 col-lg-7">
							<header class="entry-header">
								<h2 class="entry-title">Apa itu seminar dan workshop, mengapa memilih kami sebagai media partner?</h2>
							</header>
							<div class="entry-content">
								<p style="text-align: justify;">Seminar adalah pertemuan untuk membahas suatu masalah yang dilakukan secara ilmiah. Pada seminar biasanya menampilkan satu atau beberapa pembicara yang membahas suatu topik khusus. Workshop adalah acara dimana pembicara memberikan overview pada topik tertentu dan peserta akan ditugaskan untuk membahas masalah praktis sesuai topik.
								</p>
							</div>
							<!-- <div class="entry-content">
								<p style="margin-bottom: 0">Tue, Oct 15, 6:00pm</p>
								<p style="margin-bottom: 0">Taman Mini Indonesia Indah, Jakarta Timur, DKI Jakarta</p>
								<p>Free</p>
							</div> -->
						</div>
					</div>
				</div>
			</section>
			<!-- End popular Area -->


			<!-- Start calender Area -->
			<section class="calender-area relative section-gap" id="Calendar1" style="background-image: url(img/calender-bg1.png);">
				<div class="overlay overlay-bg"></div>
				<div class="container">
					<div class="row d-flex justify-content-center">
						<div class="col-md-8 pb-80 header-text">
							<h1>Event Calendar</h1>
							<p>Ayo tentukan jadwal dari setiap kesibukan aktivitas kalian, untuk dapat mengikuti setiap acara-acara seminar kami.</p>
						</div>
					</div>
					<div class="row">
						<div class="col-lg-12 calender-wrap" id="calendar"></div>
						<?php 
						
						$sql = mysqli_query($conn, "SELECT * FROM event WHERE month(date)=month(now()) ORDER BY `date` ASC");
						while ($value = mysqli_fetch_array($sql)) {
							?>
							<div class="col-lg-12 event-dates date_<?php echo date("d_M_Y", strtotime($value['date'])) ?>" style="display: none;">
								<div class="single-event d-flex flex-row">
									<p class="col-2">
										<?php $date = $value['date']; echo date("M d", strtotime($date)) ?>
									</p>
									<p class="col-7">
										<?php echo $value['subject']; ?>
									</p>
									<p class="col-3 text-right">
										<?php echo $value['payment']; ?>
									</p>
								</div>
							</div>
						<?php } ?>
					</div>
				</div>
			</section>
			<!-- End calender Area -->


			<!-- Start events Area -->
			<section class="events-area section-gap" id="upcoming">
				<div class="container">
					<div class="row d-flex justify-content-center">
						<div class="col-md-8 pb-80 header-text">
							<h1>Upcoming Events</h1>
							<p>Segera daftarkan diri kalian sebelum event berakhir dan jangan sampai terlewatkan setiap dari acara-acara menarik lainnya.
							</p>
						</div>
					</div>
					<div class="row no-padding">
						<?php 
						$sql = mysqli_query($conn, "SELECT * FROM event ORDER BY `date` ASC");
						while ($value = mysqli_fetch_assoc($sql)) {
							?>
							<div class="col-lg-6 col-sm-6 text-center">
								<div class="single-events row no-padding">
									<div class="col-lg-4 image">
										<a href="<?php echo $value['img'] ?>"><img src="<?php echo $value['img'] ?>" alt="" style="max-width: 100%; height: auto;"></a>
									</div>
									<div class="col-lg-6 details text-left">
										<h4><?php echo $value['subject'] ?></h4>
										<p class="font-weight-bold	mb-1"><?php echo $value['description']; ?></p>
										<table>
											<tr>
												<th style="position: absolute;"><span class="pr-2 fa fa-user"></span></th>
												<td><span><?php echo $value['company']; ?></span></td>
											</tr>											
											<tr>
												<th style="position: absolute;"><span class="pr-2 fa fa-map-marker"></span></th>
												<td><span><?php echo $value['location']; ?></span></td>
											</tr>
											<tr>
												<th><span class="pr-2 fa fa-calendar"></span></th>
												<td><span><?php $date = $value['date']; echo date("l, d F Y", strtotime($date)) ?></span></td>
											</tr>
											<tr>
												<th><span class="pr-2 fa fa-money"></span></th>
												<td><span><?php echo $value['payment']; ?></span></td>
											</tr>	
											<tr>
												<th style="position: absolute;"><span class="pr-2 fa fa-tags"></span></th>
												<td><span><?php echo $value['category']; ?></span></td>
											</tr>										
										</table>									
									</div>
								</div>
							</div>
						<?php } ?>
					</div>
				</div>
			</section>
			<!-- End events Area -->


			<!-- start footer Area -->
			<footer class="footer-area section-gap">
				<div class="container">
					<div class="row">
						<div class="col-lg-3  col-md-12">
							<div class="single-footer-widget">
								<h6>Popular</h6>
								<ul class="footer-nav">
									<li><a href="#home">Home</a></li>
									<li><a href="#speaker">Event</a></li>
									<li><a href="#Calendar1">Calendar</a></li>
									<li><a href="#upcoming">Upcoming</a></li>
								</ul>
							</div>
						</div>
						<div class="col-lg-6  col-md-12">
							<div class="single-footer-widget newsletter">
								<h6>Newsletter</h6>
								<p>You can trust us. we only send promo offers, not a single spam.</p>
								<div id="mc_embed_signup">
									<form target="_blank" novalidate="true" action="https://gmail.us4.list-manage.com/subscribe/post?u=7fe098497e8b6f3faba0985f0&amp;id=a744a209eb" method="get" class="form-inline">
										<div class="form-group row" style="width: 100%">
											<div class="col-lg-8 col-md-12">
												<input name="EMAIL" placeholder="Enter Email" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter Email '" required="" type="email">
												<div style="position: absolute; left: -5000px;">
													<input name="b_36c4fd991d266f23781ded980_aefe40901a" tabindex="-1" value="" type="text">
												</div>
											</div>
											<div class="col-lg-4 col-md-12">
												<button class="nw-btn primary-btn">Subscribe<span class="lnr lnr-arrow-right"></span></button>
											</div>
										</div>
										<div class="info"></div>
									</form>
								</div>
							</div>
						</div>
						<div class="col-lg-3  col-md-12">
							<div class="single-footer-widget">
								<h6>Have a Questions?</h6>
								<ul class="footer-nav">
									<li><a href="mailto:contact@mainevent.site?Subject=Hello%20Admin" target="_blank">
										<span class="fa fa-envelope"></span>
										<span class="text">contact@mainevent.site</span></a>
									</li>
									<li><a href="https://www.instagram.com/mainevent.site/?hl=en" target="_blank">
										<span class="fa fa-instagram"></span> 
										<span class="text">mainevent.site</span></a>
									</li>
								</ul>
							</div>
						</div>
					</div>

					<div class="row footer-bottom d-flex justify-content-between">
						<p class="col text-center footer-text m-0 text-white">
							Copyright Main Event &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved
						</p>
					</div>
				</div>
			</footer>
			<!-- End footer Area -->

			<script src="js/vendor/jquery-2.2.4.min.js"></script>
			<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
			<script src="js/vendor/bootstrap.min.js"></script>
			<script src="js/jquery.ajaxchimp.min.js"></script>
			<script src="js/availability-calendar.js"></script>
			<script src="js/jquery.sticky.js"></script>
			<script src="js/parallax.min.js"></script>
			<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
			<script src="js/countdown.js"></script>
			<script src="js/jquery.magnific-popup.min.js"></script>
			<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.24.0/moment.min.js"></script>
			<script src="js/main.js"></script>
			<script>
				ScrollReveal().reveal('#speaker', {delay : 200} );
				ScrollReveal().reveal('#Calendar1', {delay : 200} );
				ScrollReveal().reveal('#upcoming', {delay : 200} );

				$(document).ready(function() {
					$('.availability-calendar').on('click', 'td', function() {
						$('.event-dates').hide();
						const day = $(this).text();
						const month_year = $($('.availability-calendar-toolbar > span').first()[0]).text();
						console.log('test1', `${day} ${month_year}`);
						const mmt = moment(`${day} ${month_year}`, 'D MMMM YYYY');
						const fMMt = mmt.format('DD_MMM_YYYY');
						$('.date_'+fMMt).show();
					})
				});
			</script>
		</body>
		</html>